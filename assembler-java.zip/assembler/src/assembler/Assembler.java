/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assembler;
import java.util.*;
import java.io.*;
/**
 *
 * @author hbao
 */
public class Assembler {

    /**
     * @param args the command line arguments
     */
    SymbolTable symtab;  
    int locationCounter; // machine code/data for this line will go at this address

    // we will parse a line into these pieces,  any of which might be null.
    String labelOfThisLine;
    String operationOfThisLine; 
    String operand1ofThisLine;
    String operand2ofThisLine;
    String operand3ofThisLine;

    BufferedReader br;
    PrintWriter output;
    
    // in this assembler, whitespace separates everything, not commas.
    // comments are not allowed.
    // lines with labels must have them in the first column.
    // lines without labels must have a blank in the first column.
    // Almost no error checking is done....

    // students should not have to modify this or use it in their added code.
    void readAndParseLine(){
        try {
            String line = br.readLine();
            labelOfThisLine = operationOfThisLine = operand1ofThisLine =
                operand2ofThisLine = operand3ofThisLine = null;

            if (line.length() == 0) return;

            Scanner s = new Scanner(line);

            if (!Character.isWhitespace(line.charAt(0)))
                // line with a label
                labelOfThisLine = s.next();
                
            if (s.hasNext()) operationOfThisLine = s.next().toLowerCase();
            if (s.hasNext()) operand1ofThisLine = s.next();
            if (s.hasNext()) operand2ofThisLine = s.next();
            if (s.hasNext()) operand3ofThisLine = s.next();
        }
        catch (IOException ioe) {};  // slacker!
    }


    // students may need to use this, but they won't need to modify it
    // parse an integer constant in book's hex notation, or in decimal
    int getIntegerConstant(String theConstant) {
        if (theConstant.toLowerCase().startsWith("x") || theConstant.toLowerCase().startsWith("#")) //add lowercase and # by me
            return Integer.parseInt(theConstant.substring(1), 16);
        else
            return Integer.parseInt(theConstant);
    }

    // Students will need this to add the LD/ST/LDI/STI/LEA instructions
    // parse a register name into a code 0-7.  -1 means string is not a register name
    int getRegisterNum(String thePossibleRegisterName) {
        String [] regNames = {"R0","R1","R2","R3","R4","R5","R6","R7"};
        for (int i=0; i < regNames.length; ++i)
            if (regNames[i].equals(thePossibleRegisterName)) return i;
        return -1;  // not register name
    }

    // This is how you send machine codes to out.bin.
    // output a line as a 16-bit binary number
    // students will need to use this, but should not have to modify it.
    void emit( int value) {
        // ensure negative values are truncated to 16 bits.
        value &= 0xFFFF; 
        String s = Integer.toBinaryString(value);
        while (s.length() < 16)  // do padding.
            s = "0"+s;
        output.println(s);
    }

    // reads lines of .asm file, determines the effect on the location counter
    // and, if it is pass2, generates code.
    // This code handles both pass1 and pass2.

    // students will need to modify this method to add support for new instructions.
    // note that instructions will appear in lower case.

    void processLines(boolean isPassTwo) {
        locationCounter = 0;   

        do {
            readAndParseLine();
            
            // .orig could affect the first label
            if (operationOfThisLine != null && operationOfThisLine.equals(".orig"))
                // cannot handle .orig except at start of program
                if (locationCounter != 0) 
                    throw new RuntimeException(".orig not supported after any code generated");
                else  {
                    locationCounter = getIntegerConstant(operand1ofThisLine);
                    if (isPassTwo)  emit(locationCounter);
                }

            if (labelOfThisLine != null && !isPassTwo)
                symtab.addSymbol(labelOfThisLine, locationCounter);

            // if there is no operation, process next line
            if (operationOfThisLine == null) continue;

            // now see how this operation/pseudoop advances the location counter.
            // normally, machine ops and .fill generate 1 word of data.
            if (operationOfThisLine.equals(".stringz")) {
                // assume that operand starts and ends with quotes
                // for all characters except opening and closing quotes.
                if (isPassTwo) {
                    for (int i=1; i < operand1ofThisLine.length()-1; ++i)
                        emit( (int) operand1ofThisLine.charAt(i));
                    emit(0);  // the Z in .STRINGZ
                }
                locationCounter += operand1ofThisLine.length()-2+1; // account for surrounding quotes
            }
            else if (operationOfThisLine.equals(".fill")) {
                int fillval = getIntegerConstant(operand1ofThisLine);
                if (isPassTwo) emit(fillval);
                locationCounter += 1;
            }
            else if (operationOfThisLine.equals(".end"))
                locationCounter += 0;  // no code generated
            else if (operationOfThisLine.equals(".orig"))
                locationCounter += 0;  // already handled, no code generated
            else if (operationOfThisLine.equals("brnzp")) {
                locationCounter += 1;
                if (isPassTwo) {
                    int br_opCode = 0b0000;
                    int nzp_indicators = 0b111;
                    // operandsOfThisLine is assumed to be a label
                    int whereToBranch = symtab.lookupSymbol(operand1ofThisLine);
                    int pcOffset9 = 0b111111111 & (whereToBranch - locationCounter);
                    // assemble the bits into a machine code word.
                    int machineCode = (br_opCode << 12) | (nzp_indicators << 9) | pcOffset9;
                    emit(machineCode);
                }
            }
            else {
                locationCounter += 1;
                if (isPassTwo) {
                    emit(-1); 
                    System.err.println("emitting junk code for unhandled operation "+
                                       operationOfThisLine);
                }
            }
        }
        while ( operationOfThisLine == null ||  !operationOfThisLine.equals(".end"));
    }


    // run pass1 and pass2.  Students should not need to call or modify this.
    void assemble() {
        try {
            System.out.println("starting pass 1");
            symtab = new SymbolTable();
            br = new BufferedReader( new FileReader("p1.asm"));
            processLines(false); // not pass2
            br.close();
            
            System.out.println("The symbol table is ");
            symtab.printSymbolTable(System.out);
            
            System.out.println("starting pass 2");
            output = new PrintWriter(new FileOutputStream("out.bin"));
            br = new BufferedReader( new FileReader("p1.asm"));
            processLines(true); // not pass2
            br.close();
            output.close();
            System.out.println("finishing pass 2, output written to out.bin");
        }
        catch(Exception e) {e.printStackTrace();} 
    }

    public static void main(String [] argv) {
        Assembler as = new Assembler();
        as.assemble();
        
    }
}


// simple class to store and retrieve symbols
// Students will not need to modify this code.

class SymbolTable{
    Map<String,Integer> st;

    public SymbolTable() {
        st = new HashMap<>();
    }

    void addSymbol(String symbol, int address) {
        st.put(symbol,address);
    }

    int lookupSymbol(String symbol) {
        return st.get(symbol);
    }

    void printSymbolTable(PrintStream p) {
        p.println("Symbol\tValue\n-----------------------------");
        for (String sym : st.keySet())
            p.println(sym+"\tx"+Integer.toString(st.get(sym),16));
    }
}

    
